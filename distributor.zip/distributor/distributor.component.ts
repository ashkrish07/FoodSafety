import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-distributor',
  templateUrl: './distributor.component.html',
  styleUrls: ['./distributor.component.css']
})
export class DistributorComponent implements OnInit {

  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept:boolean=true;
  inboundReject:boolean=true;
  moredetails : boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;
  fileUrl;
  constructor(private sanitizer: DomSanitizer) {  }
  ngOnInit() {
    const data = 'some text';
    const blob = new Blob([data], { type: 'application/octet-stream' });

    this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
  }

  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }

  inboundfn() {
    this.inbound=false;
    this.outbound= true; 
    this.moredetails=true;   
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
     this.moredetails=true;
  }

  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;
  }

  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }

  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }

  public transfer(binlocation,intime){
        this.assetCreated=true;
        this.assetTransferred=false;
      }
}

