import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-histroy',
  templateUrl: './histroy.component.html',
  styleUrls: ['./histroy.component.css']
})
export class HistroyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  getSearchDetails(searchTxt)
  {
    console.log("Search functionality goes here!!");
  }
}
